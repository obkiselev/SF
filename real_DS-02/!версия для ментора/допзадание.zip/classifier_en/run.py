from application import app
from spam_classifier_en import train
train()