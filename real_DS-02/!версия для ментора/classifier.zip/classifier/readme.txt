set FLASK_DEBUG=1

set FLASK_APP=run.py

python -m flask run