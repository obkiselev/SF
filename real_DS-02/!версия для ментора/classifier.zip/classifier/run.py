from application import app
from spam_classifier import train
train()